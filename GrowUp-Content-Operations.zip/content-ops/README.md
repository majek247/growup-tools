# GrowUp Content Operations
Twelve complete JSX tools for the GrowUp Next.js Pages Router toolkit with the Agency Hiring and PDF-enabled Briefs packs installed.

## Install in Codespaces
Upload GrowUp-Content-Operations.zip beside package.json. Paste into the terminal:

```bash
cd /workspaces/growup-tools &&
ops_dir=$(mktemp -d) &&
unzip -q GrowUp-Content-Operations.zip -d "$ops_dir" &&
python3 "$ops_dir/content-ops/install.py" &&
npm test &&
npm run build
```

Start or restart npm run dev, open port 3000, visit /tools/ and click Content Operations. The topic-filter URL is /tools/?topic=Content+Operations. Use example fills in a realistic starting point. Review & export provides copy and downloadable PDF. Drafts are stored in the browser tab when session storage is available. PDF pagination follows the length of your answers.

## Editing
Each tool has its own JSX in components/tools/contentOps/, including field labels, examples, FAQ export and output rules. Workspace.jsx is the shared stepper, preview, forms and export UI. Change Operations.module.css to restyle only these tools. Edit titles, descriptions and slugs in lib/contentOpsCatalog.mjs. If renaming a slug, also update registry.js and icons.js. The sample rates and budgets are illustrative and editable. Use one period and currency across all three production models.

## Custom installations
The installer adds contentOpsTools to the public tools array before topics and types are derived, adds contentOpsComponents to toolComponents in pages/tools/[slug].jsx and uses contentOpsIcons in Directory.jsx. The existing sitemap build reads the combined public array. If the installer reports a customised integration point, copy the components, lib and tests files into matching folders. Import and spread these same registries in those three places. Preserve all existing entries. The included PDF export requires pdf-lib (installed with the earlier Briefs pack); if missing, run npm install pdf-lib@1.17.1. Review the Git diff before committing.
