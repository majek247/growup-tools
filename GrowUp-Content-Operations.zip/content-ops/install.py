"""Install Content Operations in the GrowUp Pages Router toolkit."""
from pathlib import Path
import re
import sys

root = Path.cwd()
source = Path(__file__).resolve().parent
staged = {}

def patch(name, marker, pattern, replacement, prefix):
    path = root / name
    if not path.is_file():
        sys.exit(f"Missing {name}. Run the installer from the project root.")
    text = path.read_text()
    if marker in text:
        return
    if len(re.findall(pattern, text)) != 1:
        sys.exit(f"Could not identify the integration point in {name}. See README.md. No files changed.")
    staged[path] = prefix + re.sub(pattern, replacement, text, count=1)

patch('lib/catalog.mjs','...contentOpsTools',r'export\s+const\s+topics\s*=',
      'const existingTools = tools;\nexport const topics =','')
# Expose the extended array before the existing dynamic topic/type lists run.
catalog=root/'lib/catalog.mjs'
if catalog in staged:
    text=staged[catalog]
    if 'workbenchTools' not in text or not re.search(r'new Set\(tools\.map',text):
        sys.exit('Expected the Agency Hiring catalogue with dynamic topic/type lists. See README.md.')
    text,count=re.subn(r'export\s+const\s+tools\s*=', 'const previousTools =',text)
    if count != 1: sys.exit('Could not locate the public tools array. No files changed.')
    staged[catalog]='import { contentOpsTools } from "./contentOpsCatalog.mjs";\n'+text.replace('const existingTools = tools;', 'export const tools = [...previousTools, ...contentOpsTools];')
patch('pages/tools/[slug].jsx','...contentOpsComponents',r'(const\s+toolComponents\s*=\s*\{)',r'\1\n  ...contentOpsComponents,',
      'import { contentOpsComponents } from "../../components/tools/contentOps/registry";\n')
patch('components/Directory.jsx','contentOpsIcons[slug]',r'(export function ToolIcon\([^)]*\)\s*\{\s*const Icon\s*=)',r'\1 contentOpsIcons[slug] ||',
      'import { contentOpsIcons } from "./tools/contentOps/icons";\n')
for base in ['components','lib','tests']:
    for path in (source/base).rglob('*'):
        if path.is_file():
            dest=root/path.relative_to(source)
            if dest.exists() and dest.read_bytes()!=path.read_bytes():
                sys.exit(f'{dest.relative_to(root)} already contains different code. No files changed.')
            if not dest.exists():
                staged[dest]=path.read_text()
for path,data in staged.items():
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(data)
    print(path.relative_to(root))
print('Content Operations installed.' if staged else 'Already installed.')
