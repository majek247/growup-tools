"""Install only this add-on into the GrowUp Next.js repository."""
import re
import sys
from pathlib import Path

source = Path(__file__).resolve().parent
root = Path.cwd()
edits = {}


def edit(path, marker, transform):
    path = root / path
    text = path.read_text()
    if marker not in text:
        updated = transform(text)
        if updated == text:
            sys.exit(f"Unrecognised file layout in {path}. See INSTALL.md for manual integration.")
        edits[path] = updated


def integrate_page(text):
    registry = r"(const\s+toolComponents\s*=\s*\{)"
    if not re.search(registry, text) or "customTool?.faqs" not in text:
        sys.exit("First apply the per-tool FAQ registry change in pages/tools/[slug].jsx, or use the manual instructions in INSTALL.md.")
    return 'import { schemaComponents } from "../../components/tools/schemaRegistry";\n' + re.sub(registry, r"\1\n  ...schemaComponents,", text, count=1)


def integrate_catalog(text):
    old = "export const tools = rows.map("
    if old not in text:
        return text
    return 'import { schemaTools } from "./schemaCatalog.mjs";\n'+text.replace(old, "export const workbenchTools = rows.map(", 1)+'\nexport const tools = [...workbenchTools, ...schemaTools];\n'


if not (root / "lib/catalog.mjs").is_file():
    sys.exit("Run this command from the growup-tools repository root.")
edit("pages/tools/[slug].jsx", "...schemaComponents,", integrate_page)
edit("lib/catalog.mjs", "...schemaTools]", integrate_catalog)
tests = root / "tests/tools.test.mjs"
if tests.exists() and "of tools.entries()" in tests.read_text():
    edit("tests/tools.test.mjs", "workbenchTools as tools", lambda t: t.replace("import { tools }", "import { workbenchTools as tools }", 1))
directory = root / "components/Directory.jsx"
if directory.exists():
    text = directory.read_text()
    updated = text.replace("Explore 12 free tools", "Explore free tools")
    if updated != text:
        edits[directory] = updated

for folder in ["components", "lib"]:
    for path in (source / folder).rglob("*"):
        if path.is_file():
            dest = root / path.relative_to(source)
            if dest.exists() and dest.read_bytes() != path.read_bytes():
                sys.exit(f"{dest} already contains different code. Compare it with the add-on before installing.")
            if not dest.exists():
                edits[dest] = path.read_text()
for path, content in edits.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    print(path.relative_to(root))
print("Five schema tools registered. Run npm test && npm run build.")
