# GrowUp schema generators

This add-on extends the GrowUp toolkit with five Technical SEO generators. The per-tool FAQ registry from the SERP and FAQ migration must already be in use for automatic installation.

## Install from Codespaces

Upload GrowUp-Schema-Generators.zip to the repository root and run:

```bash
cd /workspaces/growup-tools
addon_dir=$(mktemp -d) &&
unzip -q GrowUp-Schema-Generators.zip -d "$addon_dir" &&
python3 "$addon_dir/schema-pack/install.py" &&
npm test &&
npm run build
```

Restart your dev server after building. Open /tools/, choose Technical SEO and Generator, then open one of the five cards. The script adds source files and updates the catalogue, route registry and directory metadata. The legacy test suite continues to exercise the original workbench implementations. No new dependencies.

## Manual integration

1. Copy the contents of the add-on's components/tools and lib folders to the same folders in the repo.
2. In lib/catalog.mjs add `import { schemaTools } from "./schemaCatalog.mjs";`. Change `export const tools = rows.map(` to `export const workbenchTools = rows.map(`. After that definition, add `export const tools = [...workbenchTools, ...schemaTools];`.
3. In pages/tools/[slug].jsx import `{ schemaComponents }` from `"../../components/tools/schemaRegistry"`. Add `...schemaComponents,` inside your existing toolComponents object. The page should select `toolComponents[tool.slug]?.Component ?? Workbench` and display the selected entry's faqs array in its FAQ section. Keep any existing SERP and FAQ entries and the old fallback for other tools.
4. In tests/tools.test.mjs change the original catalogue import to `import { workbenchTools as tools } from "../lib/catalog.mjs";`. The original fixture loop calls run() on the original workbench tools. New generators have independent build functions in their JSX.
5. In components/Directory.jsx update “Explore 12 free tools” to “Explore free tools”. The visible filter counts, sitemap and generated page URLs use the catalogue automatically.
6. Run npm test and npm run build.

## Edit

Each named generator JSX contains its editable field groups, example, named faqs export and build function. SchemaStudio.jsx handles form state, repeatable inputs, code preview and export. SchemaStudio.module.css styles only these forms. lib/schemaCatalog.mjs contains the five meta titles, descriptions and directory entries.

## Validation

These checks run locally on entered data. They do not fetch pages or assets, verify visible claims or guarantee eligibility. Use the Google testing link on the output panel after copying the embed. Examples are fictional.

Google Search Central references:
- https://developers.google.com/search/docs/appearance/structured-data/organization
- https://developers.google.com/search/docs/appearance/structured-data/product-snippet
- https://developers.google.com/search/docs/appearance/structured-data/article
- https://developers.google.com/search/docs/appearance/structured-data/video
- https://developers.google.com/search/docs/appearance/structured-data/review-snippet
