"""Install the three brief dashboards into the existing GrowUp agency hiring pack."""
from pathlib import Path
import re

root = Path.cwd()
src = Path(__file__).resolve().parent
stage = {}

def read(name):
    path = root / name
    if not path.exists():
        raise SystemExit(f'Missing {name}. Run from the toolkit root with the GrowUp Agency Hiring pack installed.')
    return path.read_text()

def once(text, pattern, replacement, label):
    text, count = re.subn(pattern, lambda _: replacement, text)
    if count != 1:
        raise SystemExit(f'Could not identify {label} uniquely. No changes written. See README.md.')
    return text

registry = 'components/tools/hiring/registry.js'
reg = read(registry)
if './briefs/ContentAgencyBriefBuilder' not in reg:
    reg = once(reg,r'(["\'])\./SeoAgencyBriefBuilder\1','"./briefs/SeoAgencyBriefBuilder"','the existing SEO brief import')
    reg = once(reg,r'export const hiringComponents\s*=\s*\{','''export const hiringComponents = {
  "content-agency-brief-builder": { Component: ContentBrief, faqs: contentFaqs },
  "link-building-brief-builder": { Component: LinkBrief, faqs: linkFaqs },''','the hiring registry')
    stage[registry] = ('import ContentBrief, { faqs as contentFaqs } from "./briefs/ContentAgencyBriefBuilder";\n'
                       'import LinkBrief, { faqs as linkFaqs } from "./briefs/LinkBuildingBriefBuilder";\n'+reg)
catalog = 'lib/hiringCatalog.mjs'
cat = read(catalog)
if '"content-agency-brief-builder"' not in cat:
    stage[catalog] = once(cat,r'export const hiringTools\s*=\s*\[','''export const hiringTools = [
  ["content-agency-brief-builder","Content agency brief builder","Builder","Commission a comparison page, case study, guide or landing page. Agree the audience, evidence and approval criteria, then download the writing brief as a PDF."],
  ["link-building-brief-builder","Link building agency brief builder","Builder","Brief an outreach agency on target pages, editorial standards, prospect approval and placement reporting. Download your campaign brief as a PDF."],''','the hiring catalogue')
test = 'tests/hiring.test.mjs'
if (root/test).exists():
    old = read(test)
    oldcount = r'assert\.equal\(tools\.filter\(\(t\) => t\.topic === "Agency hiring"\)\.length, 3\);'
    updated = re.sub(oldcount,'''for (const slug of ["seo-agency-brief-builder","content-agency-brief-builder","link-building-brief-builder"]) {
    assert.equal(tools.filter(t => t.slug === slug && t.topic === "Agency hiring").length, 1);
  }''',old).replace('Three agency tools replace the retired public pages','Agency hiring includes the brief builders and omits retired pages')
    if updated != old: stage[test] = updated
for path in (src/'components').rglob('*'):
    if path.is_file():
        rel = str(path.relative_to(src))
        if (root/rel).exists():
            if read(rel) != path.read_text(): raise SystemExit(f'Existing edits in {rel}. Compare manually before installing.')
        else: stage[rel] = path.read_text()
for rel, text in stage.items():
    path = root/rel
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text)
    print(rel)
print('Brief builders installed.' if stage else 'Already installed.')
