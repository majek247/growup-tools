# GrowUp agency briefs
Upload GrowUp-Agency-Briefs.zip beside package.json in your existing GrowUp toolkit with the Agency Hiring pack installed. In the Codespaces terminal run:

```bash
cd /workspaces/growup-tools &&
brief_dir=$(mktemp -d) &&
unzip -q GrowUp-Agency-Briefs.zip -d "$brief_dir" &&
python3 "$brief_dir/brief-pack/install.py" &&
npm install pdf-lib@1.17.1 &&
npm test &&
npm run build
```

Run `npm run dev` and open port 3000. If a dev server is already running, restart it. The directory topic is Agency hiring. Routes are /tools/seo-agency-brief-builder/, /tools/content-agency-brief-builder/ and /tools/link-building-brief-builder/. Review your git diff, including package.json, the lockfile and sitemap, before committing.

## Files and integration
Each tool in components/tools/hiring/briefs has its own JSX, sample, questions, PDF sections and named FAQ export. Dashboard.jsx implements the step navigation and review. Dashboard.module.css scopes the responsive design. saveBrief.js generates paginated A4 PDFs in the browser. No server keys are needed.

The installer redirects the existing SEO brief registry import, adds two catalogue entries and two registry entries, and updates the original fixed-count hiring test if found. The old builder file is retained for rollback. Existing comparison and trial pages continue to work.

If your registry was customised, copy the briefs folder to components/tools/hiring/. In registry.js import the default component and named faqs from each of the three new JSX files. Use the three slugs above (without /tools/ or slashes) as registry keys with { Component, faqs }. Add the two new rows from install.py to lib/hiringCatalog.mjs. Keep the existing SEO slug once. Run the dependency, test and build commands above.

## Using the tools
Start with your own details or load an example. Use the numbered navigation to jump between decisions. Optional fields sit under Additional detail. Notes serve as private working material. Labelled note lines such as “Company: RelayLedger” or “Budget: £4,000 per month” can be applied with one click. Unlabelled notes are retained as reference. A CMS capacity cue can suggest agency publishing for confirmation. Nothing is sent to an AI service.

Review & download displays the agency-facing sections. Edit the wording with each pencil control. A later input change regenerates the affected review section from the inputs; other section edits are retained. Required fields are listed before export; optional decisions can be left for confirmation. Drafts use session storage per tool. Save the PDF before closing the tab.
