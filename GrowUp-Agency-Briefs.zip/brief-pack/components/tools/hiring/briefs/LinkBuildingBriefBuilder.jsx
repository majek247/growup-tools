import Dashboard from "./Dashboard";
import {
  field,
  choice,
  company,
  notes,
  audience,
  budget,
  deadline,
  success,
  faqsFor,
} from "./fields";
const tactics = {
  "Expert commentary":
    "Prepare a spokesperson biography, approved topics and a turnaround time for journalist requests.",
  "Original research":
    "Prepare the dataset, methodology, limitations and a quotable finding for the pitch.",
  "Resource outreach":
    "Explain the editorial gap the resource fills for each publication’s readers.",
  "Unlinked mentions":
    "Verify each brand mention and the most relevant destination before contacting the editor.",
};
const steps = [
  {
    title: "Campaign purpose",
    prompt: "Who should discover your company?",
    fields: [
      company,
      notes,
      audience,
      field(
        "goal",
        "Campaign objective",
        "For example, reach finance leaders researching billing automation.",
        { required: true },
      ),
    ],
  },
  {
    title: "Assets and targets",
    prompt: "What would an editor want to reference?",
    fields: [
      choice("tactic", "Outreach approach", Object.keys(tactics)),
      field(
        "targets",
        "Destination pages",
        "List the URLs and why each is useful to readers.",
        { long: true },
      ),
      field(
        "asset",
        "Pitchable evidence",
        "Original data, expert, research or an existing mention.",
      ),
      field(
        "markets",
        "Markets and publication types",
        "For example, UK finance trade publications.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Editorial guardrails",
    prompt: "Which prospects can the agency approach?",
    fields: [
      choice("approval", "Prospect approval", [
        "Approve each shortlist",
        "Approve criteria, then spot-check",
      ]),
      field(
        "quality",
        "Acceptance criteria",
        "Audience overlap, editorial relevance and evidence of original reporting.",
      ),
      field(
        "exclude",
        "Exclusions / do-not-contact list",
        "Paste domains, partners, customers or restricted verticals.",
        { long: true },
      ),
      field(
        "voice",
        "Spokesperson and sign-off",
        "Who approves a quote or an outreach email?",
        { extra: true },
      ),
    ],
  },
  {
    title: "Reporting and fees",
    prompt: "What evidence should accompany delivery?",
    fields: [
      budget,
      deadline,
      success,
      field(
        "report",
        "Reporting cadence and owner",
        "Who reviews prospects, pitches and live coverage?",
        { extra: true },
      ),
      field(
        "costs",
        "Expense approval",
        "What needs approval before the agency spends?",
        { extra: true },
      ),
    ],
  },
];
const config = {
  id: "links",
  title: "Link building agency brief",
  steps,
  sample: {
    company: "RelayLedger",
    audience: "Finance operations teams at UK B2B SaaS companies.",
    goal: "Earn relevant coverage for our billing benchmark.",
    tactic: "Original research",
    targets: "/research/billing-benchmark — public dataset and methodology.",
    asset:
      "Approved aggregate figures across 150 billing teams. Methodology available to editors.",
    approval: "Approve each shortlist",
    quality:
      "Finance or SaaS readership, named editor, original reporting and clear topical fit.",
    exclude: "Existing customers and our syndication partners.",
    budget: "£3,000 for an eight-week pilot",
    deadline: "Begin pitching after the benchmark launches.",
    success: "Qualified referral visits and relevant editorial coverage.",
  },
  build(v) {
    return [
      [
        "Outreach preparation",
        tactics[v.tactic] ||
          "Agree the outreach method and supporting materials before pitching.",
      ],
      [
        "Prospect approval",
        v.approval === "Approve each shortlist"
          ? "Send domain, example article, audience fit, target URL and proposed angle. Wait for approval before contacting each shortlist."
          : v.approval === "Approve criteria, then spot-check"
            ? "Agree sample prospects first. Log each domain and rationale for buyer spot-checks before follow-up."
            : "Confirm who signs off prospects before outreach begins.",
      ],
      [
        "Placement evidence and costs",
        "Report live URL, destination, anchor, publication date, link attribute and relevance. Separate pitched, accepted and live coverage. Itemise research, prospecting and outreach. Disclose sponsorship and obtain approval for fees before committing spend.",
      ],
    ];
  },
};
export const faqs = faqsFor({
  question: "What does the agency need to report?",
  answer:
    "The brief requests a record of each live placement, its destination and relevance, plus a separate view of pitches, accepted ideas and published coverage. You can add your own targets and exclusions.",
});
export default function LinkBuildingBriefBuilder() {
  return <Dashboard config={config} />;
}
