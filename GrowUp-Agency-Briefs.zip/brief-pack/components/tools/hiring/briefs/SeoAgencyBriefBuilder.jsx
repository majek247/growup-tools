import Dashboard from "./Dashboard";
import {
  field,
  choice,
  company,
  notes,
  audience,
  budget,
  deadline,
  success,
  owner,
  faqsFor,
} from "./fields";

const programme = choice("programme", "What should the agency own?", [
  "Managed SEO",
  "Technical recovery",
  "Strategy and advisory",
]);
const scopes = {
  "Managed SEO": [
    "Interview sales and audit the pages buyers visit before booking a demo.",
    "Ship the agreed fixes and priority commercial pages with named owners.",
    "Review indexed pages, qualified enquiries and opportunities with sales.",
  ],
  "Technical recovery": [
    "Baseline affected URL groups and reproduce the indexing or crawling issue.",
    "Pilot the fix on one template and document validation and rollback steps.",
    "Recheck coverage and affected landing-page performance before wider rollout.",
  ],
  "Strategy and advisory": [
    "Review the backlog, team capacity and measurement gaps.",
    "Deliver briefs and acceptance checks for the internal implementation team.",
    "Review shipped work and agree the next quarter’s priorities.",
  ],
};
const steps = [
  {
    title: "Business context",
    prompt: "What is the agency walking into?",
    fields: [
      company,
      notes,
      audience,
      field(
        "alternatives",
        "Competitors and alternatives",
        "Name the vendors buyers shortlist, or the manual workaround you replace.",
        { extra: true },
      ),
      field(
        "trigger",
        "Buying trigger and barriers",
        "What starts an evaluation? Which objections slow a deal?",
        { extra: true },
      ),
      field(
        "site",
        "Website and markets",
        "Domain, countries and languages in scope.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Commercial goal",
    prompt: "What should change for the business?",
    fields: [
      field(
        "goal",
        "Primary objective",
        "For example, grow qualified demo requests from organic search.",
        { required: true },
      ),
      success,
      field(
        "baseline",
        "Baseline and target",
        "Current value, target and measurement period.",
        { extra: true },
      ),
      field(
        "qualified",
        "Qualified enquiry definition",
        "Specify the CRM stage, exclusion rules and person who checks lead quality.",
        { extra: true },
      ),
      field(
        "systems",
        "Data sources and access",
        "GSC, analytics, CRM and who can grant access.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Scope and ownership",
    prompt: "Who will actually ship the work?",
    fields: [
      programme,
      owner,
      field(
        "priorities",
        "Priority pages or problems",
        "Add page URLs, template names or known blockers.",
        { long: true },
      ),
      field(
        "inventory",
        "Existing work to reuse",
        "Link previous audits, briefs, content inventory or keyword research.",
        { extra: true },
      ),
      field(
        "engineering",
        "Engineering capacity",
        "Who can release technical changes and how often?",
        { extra: true },
      ),
      field(
        "approval",
        "Who approves product claims?",
        "Name a reviewer and a realistic turnaround.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Fees and timing",
    prompt: "What should every agency price?",
    fields: [
      budget,
      deadline,
      field(
        "comparison",
        "How proposals will be evaluated",
        "For example, named delivery team, relevant work and evidence behind priorities.",
        { extra: true },
      ),
      field(
        "limits",
        "Exclusions and constraints",
        "Migration dates, restricted pages or procurement requirements.",
        { extra: true },
      ),
      field(
        "lead",
        "Decision owner and proposal deadline",
        "Who will compare bids and when?",
        { extra: true },
      ),
    ],
  },
];
const config = {
  id: "seo",
  title: "SEO agency brief",
  steps,
  sample: {
    company: "RelayLedger",
    audience:
      "Finance directors at UK SaaS companies evaluating billing software.",
    notes:
      "Sales uses our comparison pages. Marketing has no CMS time. Engineering releases fortnightly.",
    goal: "Increase qualified organic demo requests over two quarters.",
    programme: "Managed SEO",
    owner: "Agency",
    priorities: "/billing-software and our two most-used comparison pages",
    baseline: "12 qualified demos per month today. Target 20 by the end of Q2.",
    systems: "Search Console and HubSpot, owned by Marketing Ops.",
    budget: "£4,500 per month",
    deadline: "Kick off in January",
    success: "Monthly qualified demos and new opportunities in HubSpot.",
  },
  build(v) {
    const plan = scopes[v.programme];
    return [
      [
        "Proposed first 90 days",
        plan
          ? plan
              .map((line, i) => "Day " + [30, 60, 90][i] + " — " + line)
              .join("\n")
          : "Ask the agency for a 30-, 60- and 90-day plan once programme scope is confirmed.",
      ],
      [
        "Pricing response requested",
        [
          "Quote discovery separately from recurring delivery.",
          v.owner === "Agency"
            ? "Itemise CMS upload, formatting and QA per page."
            : v.owner === "Internal team"
              ? "Quote handoff and CMS-ready assets. The internal team will publish."
              : "Price agency publishing as an optional line item.",
          v.programme === "Technical recovery"
            ? "Separate diagnosis, implementation and post-release validation."
            : v.programme === "Strategy and advisory"
              ? "Specify consultant hours, review rounds and delivery-team dependencies."
              : "State monthly volumes for new pages, updates and technical implementation.",
          "List third-party fees, minimum term and exclusions.",
        ].join("\n"),
      ],
      [
        "Reporting and sign-off",
        "Ask the agency to name the owner, data source and reporting cadence for each agreed metric. Record shipped work and outstanding dependencies at each review.",
      ],
    ];
  },
};
export const faqs = faqsFor({
  question: "What goes into the 90-day plan?",
  answer:
    "Your programme determines the proposed discovery, delivery and review milestones. Publishing ownership also changes the pricing request. Edit the suggested milestones on the final review screen before sharing.",
});
export default function SeoAgencyBriefBuilder() {
  return <Dashboard config={config} />;
}
