import Dashboard from "./Dashboard";
import {
  field,
  choice,
  company,
  notes,
  audience,
  budget,
  deadline,
  success,
  owner,
  faqsFor,
} from "./fields";

const assignments = {
  "Comparison page":
    "Write a decision guide covering who each product suits, material trade-offs, verified feature differences and the next step for each buyer.",
  "Customer case study":
    "Show the customer’s starting situation, why they changed, what they implemented and the measured outcome. Flag quotes and numbers for customer approval.",
  "Product-led guide":
    "Walk the reader through one real task. Show the inputs, product steps, example output and how the reader can reproduce it.",
  "Landing page":
    "Lead with the buying situation, demonstrate the product against that use case, answer objections and finish with one primary action.",
};
const steps = [
  {
    title: "Reader and context",
    prompt: "Who needs this piece, and why now?",
    fields: [company, notes, audience],
  },
  {
    title: "Content assignment",
    prompt: "What should the agency create?",
    fields: [
      choice("format", "Asset format", Object.keys(assignments)),
      field(
        "topic",
        "Working title or topic",
        "Give the writer a specific question to answer.",
        { required: true },
      ),
      field(
        "action",
        "What should the reader do next?",
        "For example, compare plans or book a technical demo.",
      ),
      field(
        "angle",
        "Angle and objections",
        "What should this cover that existing articles miss?",
        { extra: true },
      ),
      field(
        "quantity",
        "Quantity and length",
        "For example, one page plus a sales email.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Evidence and quality",
    prompt: "What can the writer use as proof?",
    fields: [
      field(
        "sources",
        "Source pack",
        "Paste URLs, approved quotes or interview notes.",
        { long: true },
      ),
      field(
        "expert",
        "Subject expert and availability",
        "Who can answer follow-up questions?",
      ),
      field(
        "voice",
        "Voice and examples",
        "Link one piece to emulate and say why.",
        { extra: true },
      ),
      field(
        "avoid",
        "Restricted claims or competitors",
        "List anything requiring legal or customer approval.",
        { extra: true },
      ),
    ],
  },
  {
    title: "Handoff and review",
    prompt: "What makes the draft ready to publish?",
    fields: [
      owner,
      deadline,
      field(
        "reviewer",
        "Approver and revision process",
        "Who owns final sign-off and how many review rounds?",
      ),
      success,
      budget,
    ],
  },
];
const config = {
  id: "content",
  title: "Content agency brief",
  steps,
  sample: {
    company: "RelayLedger",
    audience:
      "UK finance directors replacing spreadsheets before their annual billing review.",
    format: "Comparison page",
    topic: "Billing software vs spreadsheets for usage-based pricing",
    action: "Book a demo using a sample invoice.",
    sources:
      "Use the approved pricing sheet and an anonymised finance-team interview. Confirm product limits with the product owner.",
    expert: "Head of Product, available for a 20-minute interview.",
    owner: "Internal team",
    deadline: "First draft by 12 January",
    reviewer: "Product checks accuracy, then marketing signs off.",
    success: "Track demo requests from the page in HubSpot.",
  },
  build(v) {
    return [
      [
        "Commissioned assignment",
        assignments[v.format] ||
          "Confirm the asset format before commissioning a first draft.",
      ],
      [
        "Editorial acceptance checks",
        [
          "Answer the reader’s decision in the opening section.",
          v.format === "Customer case study"
            ? "Attach approval for each attributed quote and verify the outcome against its source."
            : v.format === "Comparison page"
              ? "Cite sources for material differences and date-check pricing and plan limits."
              : v.format === "Product-led guide"
                ? "Test the steps against the current product and supply captioned screenshots."
                : "Back each material product claim with a named source.",
          v.action
            ? "End with the agreed action — " + v.action
            : "Agree one next step for the reader before drafting.",
        ].join("\n"),
      ],
      [
        "Delivery and pricing request",
        [
          v.owner === "Agency"
            ? "Include CMS upload, metadata, accessibility checks and preview sign-off in the quote."
            : v.owner === "Internal team"
              ? "Supply clean copy, metadata, alt text and original assets to the internal publishing team."
              : "Quote CMS publishing separately until ownership is agreed.",
          "Itemise research, interviews, writing, design and revisions. Specify what the fee includes.",
        ].join("\n"),
      ],
    ];
  },
};
export const faqs = faqsFor({
  question: "Can I brief more than a blog post?",
  answer:
    "Choose a comparison page, customer case study, product-led guide or landing page. Each format has its own assignment and acceptance criteria.",
});
export default function ContentAgencyBriefBuilder() {
  return <Dashboard config={config} />;
}
