# GrowUp Agency Hiring Tools

## Install in Codespaces

Upload GrowUp-Agency-Hiring.zip to the repository root beside package.json. This add-on targets the existing schema-enabled toolkit with its toolComponents registry, papaparse and lucide-react dependencies.

```bash
cd /workspaces/growup-tools &&
hiring_dir=$(mktemp -d) &&
unzip -q GrowUp-Agency-Hiring.zip -d "$hiring_dir" &&
python3 "$hiring_dir/agency-hiring/install.py" &&
npm test &&
npm run build
```

If a development server is running, restart it after the build. Run npm run dev in a terminal and open port 3000. At /tools/, choose Agency hiring. To inspect the installed changes use git status --short and git diff. Publishing is a separate action.

## Public pages

| Route under /tools/ | Output |
| --- | --- |
| agency-proposal-comparison/ | Editable scope comparison for two or three quotes, CSV matrix, text summary and agency-specific email drafts |
| content-agency-paid-trial-kit/ | Paid assignment, two-candidate scorecard with evidence and CSV decision sheet |
| seo-agency-brief-builder/ | Editable 90-day brief, ownership requests and a CSV response table for agencies |

Each tool includes examples and FAQs. Inputs remain in the tab. Copy or download your work before leaving. Proposal text is parsed locally; no PDF upload or AI service is required. Check suggested values against the original quote. Contract totals cover fixed fees only. Prefer an explicit currency code for dollars if proposals are from different markets. Comparing different currencies requires a separate exchange-rate decision.

## Integration details

The installer registers the JSX components, adds metadata to the public catalogue, derives topic/type filters from listed tools, and adjusts the directory icon lookup to preserve existing workbench icons. Public catalogue filtering removes content-refresh-planner, editorial-capacity-planner and ctr-opportunity-calculator from navigation, related tools, sitemap and static page generation. Original workbench definitions and their tests remain available locally.

The installer checks its expected integration points and conflicting new file paths before writing. Rerunning the same version is supported. Keep local customisations if comparing a file conflict.

## Manual integration for a customised repository

1. From agency-hiring/ copy components/tools/hiring/, lib/hiringCatalog.mjs, lib/proposalAnalysis.mjs and tests/hiring.test.mjs into matching locations in your repository.
2. In lib/catalog.mjs import { hiringTools, retiredPlannerSlugs } from "./hiringCatalog.mjs". At the definition of the final public tools array, filter out retired slugs and append hiringTools. For the original schema-enabled toolkit:

```js
export const tools = [...workbenchTools, ...schemaTools]
  .filter(tool => !retiredPlannerSlugs.has(tool.slug))
  .concat(hiringTools);
export const topics = [...new Set(tools.map(tool => tool.topic))];
export const types = [...new Set(tools.map(tool => tool.type))];
```

Keep any additional tool collections your own version already includes. Replace previous topics and types declarations with the two declarations above and place them after tools.

3. In pages/tools/[slug].jsx import { hiringComponents } from "../../components/tools/hiring/registry". Add ...hiringComponents inside the existing toolComponents object. Keep your getStaticProps missing-tool check and current FAQ rendering.
4. In components/Directory.jsx, use workbenchTools when looking up an icon by the original index. The hiring icon names are Columns3, ClipboardCheck and FilePenLine respectively. If your icons are already mapped by slug, add entries to that map. Refresh any hardcoded tool counts or references to the former planners.
5. Run npm test and npm run build. Check the three new pages under out/tools/ and confirm the retired slugs are absent from out/sitemap.xml.

## Where to edit the tools

components/tools/hiring/ contains a JSX file for each tool, the tool-specific FAQs, a shared form/export component and a scoped stylesheet. lib/proposalAnalysis.mjs holds quote matching and fixed-fee calculations. lib/hiringCatalog.mjs holds the page titles, descriptions, slugs and classifications.
