"""Apply an additive, repeatable migration to the GrowUp toolkit from its repo root."""
import re
import sys
from pathlib import Path

root = Path.cwd()
source = Path(__file__).resolve().parent
changes = {}


def stop(message):
    sys.exit(message)


def load(path):
    file = root / path
    if not file.is_file():
        stop(f"Missing {path}. Run this installer from /workspaces/growup-tools.")
    return file, file.read_text()


def single(text, pattern, replacement, label):
    updated, count = re.subn(pattern, lambda _: replacement, text, count=1)
    if not count:
        stop(f"Could not find {label}. No files have been written. See INSTALL.md.")
    return updated


catalog, text = load("lib/catalog.mjs")
if 'import { hiringTools,' not in text:
    if "export const workbenchTools" not in text:
        stop("Expected the schema-enabled toolkit catalogue. See INSTALL.md.")
    match = re.search(r'export\s+const\s+tools\s*=\s*(\[[^\]]+\])\s*;', text)
    if not match:
        stop("Could not find the combined public tools array. See INSTALL.md.")
    public = match.group(1)
    text = text[:match.start()] + text[match.end():]
    for key in ("topics", "types"):
        pattern = rf"export\s+const\s+{key}\s*=\s*\[[^\]]*\]\s*;"
        text = single(text, pattern, "", "the " + key + " list")
    text += ("\nexport const tools = " + public
             + ".filter(tool => !retiredPlannerSlugs.has(tool.slug)).concat(hiringTools);\n"
             + "export const topics = [...new Set(tools.map(tool => tool.topic))];\n"
             + "export const types = [...new Set(tools.map(tool => tool.type))];\n")
    changes[catalog]='import { hiringTools, retiredPlannerSlugs } from "./hiringCatalog.mjs";\n'+text

route, text = load("pages/tools/[slug].jsx")
if '...hiringComponents' not in text:
    text = single(text,r'const\s+toolComponents\s*=\s*\{','const toolComponents = {\n  ...hiringComponents,','the tool component registry')
    changes[route]='import { hiringComponents } from "../../components/tools/hiring/registry";\n'+text

directory, text = load("components/Directory.jsx")
if 'hiringIcons' not in text:
    text=single(text,r'import\s*\{\s*tools\s*,\s*topics\s*,\s*types\s*\}\s*from\s*["\']../lib/catalog.mjs["\'];?', 'import { tools, topics, types, workbenchTools } from "../lib/catalog.mjs";','directory catalogue import')
    text=single(text,r'const\s+Icon\s*=\s*icons\[tools\.findIndex\(\(t\)\s*=>\s*t\.slug\s*===\s*slug\)\]\s*\|\|\s*Shapes;', 'const Icon = hiringIcons[slug] || icons[workbenchTools.findIndex((t) => t.slug === slug)] || Shapes;', 'directory icon lookup')
    text=text.replace('export function ToolIcon(','''const hiringIcons = {
  "agency-proposal-comparison": Columns3,
  "content-agency-paid-trial-kit": ClipboardCheck,
  "seo-agency-brief-builder": FilePenLine,
};
export function ToolIcon(''')
    if 'const hiringIcons =' not in text:
        stop("Could not locate ToolIcon. See INSTALL.md.")
    text=re.sub(r'Work backwards from revenue, find your next content update and\s+measure where buyers see you in AI search\.', 'Plan organic revenue, compare agency proposals and prepare a paid content trial for your shortlist.',text)
    text=text.replace('Plan organic pipeline, prioritise content updates, measure AI visibility and generate SEO files','Plan organic pipeline, compare agencies, brief writers and generate SEO files')
    changes[directory]='import { Columns3, ClipboardCheck, FilePenLine } from "lucide-react";\n'+text

for folder in ["components","lib","tests"]:
    for path in (source/folder).rglob("*"):
        if not path.is_file():
            continue
        dest=root/path.relative_to(source)
        if dest.exists() and dest.read_bytes()!=path.read_bytes():
            stop(f"{dest.relative_to(root)} has different contents. Compare it with the add-on. No files written.")
        if not dest.exists():
            changes[dest]=path.read_text()

for path, content in changes.items():
    path.parent.mkdir(exist_ok=True,parents=True)
    path.write_text(content)
    print(path.relative_to(root))
print("Agency hiring installed." if changes else "Agency hiring is already installed.")
