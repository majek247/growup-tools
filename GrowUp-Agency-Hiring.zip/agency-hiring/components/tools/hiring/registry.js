import Comparison, { faqs as proposalFaqs } from "./AgencyProposalComparison";
import TrialKit, { faqs as trialFaqs } from "./ContentAgencyPaidTrialKit";
import BriefBuilder, { faqs as briefFaqs } from "./SeoAgencyBriefBuilder";
export const hiringComponents = {
  "agency-proposal-comparison": { Component: Comparison, faqs: proposalFaqs },
  "content-agency-paid-trial-kit": { Component: TrialKit, faqs: trialFaqs },
  "seo-agency-brief-builder": { Component: BriefBuilder, faqs: briefFaqs },
};
